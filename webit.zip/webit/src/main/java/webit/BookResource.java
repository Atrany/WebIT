package webit;

import java.util.List;
import io.vertx.core.Vertx;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class BookResource {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookResource.class);

    private final BookService bookService = new BookService();
  
    public Router getSubRouter(final Vertx vertx) {
      final Router subRouter = Router.router(vertx);

      subRouter.route("/*").handler(BodyHandler.create());

      subRouter.get("/").handler(this::getAllBooks);
      subRouter.get("/:id").handler(this::getOneBook);
      subRouter.post("/").handler(this::createOneBook);
      subRouter.put("/:id").handler(this::updateOneBook);
      subRouter.delete("/:id").handler(this::deleteOneBook);
  
      return subRouter;
    }
    
    private void getAllBooks(final RoutingContext routingContext) {
        LOGGER.info("Dans getAllBooks...");
    
        final List<Book> books = bookService.findAll();
    
        final JsonObject jsonResponse = new JsonObject();
        jsonResponse.put("books", books);

    
        routingContext.response()
            .setStatusCode(200)
            .putHeader("content-type", "application/json")
            .end(Json.encode(jsonResponse));
      }
    
      private void getOneBook(final RoutingContext routingContext) {
        LOGGER.info("Dans getOneBook...");
    
        final String id = routingContext.request().getParam("id");
    
        final Book book = bookService.findById(id);
    
        if (book == null) {
          final JsonObject errorJsonResponse = new JsonObject();
          errorJsonResponse.put("error", "No book can be found for the specified id:" + id);
          errorJsonResponse.put("id", id);
    
          routingContext.response()
              .setStatusCode(404)
              .putHeader("content-type", "application/json")
              .end(Json.encode(errorJsonResponse));
          return;
        }
        routingContext.response()
            .setStatusCode(200)
            .putHeader("content-type", "application/json")
            .end(Json.encode(book));
      }
      private void createOneBook(final RoutingContext routingContext) {
        LOGGER.info("Dans createOneBook...");
        final JsonObject body = routingContext.getBodyAsJson();
        final String name = body.getString("name");
        final String author = body.getString("author");
 
        final Book book = new Book(null, name, author);
        final Book createdBook = bookService.add(book);
        routingContext.response()
            .setStatusCode(201)
            .putHeader("content-type", "application/json")
            .end(Json.encode(createdBook));
      }
      private void updateOneBook(final RoutingContext routingContext) {
        LOGGER.info("Dans updateOneBook...");
        final String id = routingContext.request().getParam("id");
        final JsonObject body = routingContext.getBodyAsJson();
        final String name = body.getString("name");
        final String author = body.getString("author");
        
        final Book book = new Book(id, name, author);
        final Book updatedBook = bookService.update(book);
        routingContext.response()
            .setStatusCode(200)
            .putHeader("content-type", "application/json")
            .end(Json.encode(updatedBook));
      }
      private void deleteOneBook(final RoutingContext routingContext) {
        LOGGER.info("Dans deleteOneBook...");
        final String id = routingContext.request().getParam("id");
        bookService.remove(id);
        routingContext.response()
            .setStatusCode(200)
            .putHeader("content-type", "application/json")
            .end();
      }

}

