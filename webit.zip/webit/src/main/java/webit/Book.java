package webit;

public class Book {
    private final String id; 
    private final String name; 
    private final String author; 

    public Book(final String id, final String name, final String author){
        super(); 
        this.id = id; 
        this.name = name; 
        this.author = author; 
    }

    public String getId() {
        return this.id;
    }


    public String getName() {
        return this.name;
    }


    public String getAuthor() {
        return this.author;
    }

    @Override
    public String toString(){
        return "Book [id="+ id +", name ="+ name +", author="+ author +"]";
    }
    
}
