package webit;

import java.util.List;

public class BookService {
    public List<Book> findAll(){
        return null;
        
    }
    public Book findById(final String id) {
        return null;
        
      }
      // Mettre à jour un chien
      public Book update(final Book book) {
        return book;
        
      }
      // Effacer un chien
      public void remove(final String id) {
        
      }
      // Ajouter un chien
      public Book add(final Book book) {
        return book;
        
      }
    
}
