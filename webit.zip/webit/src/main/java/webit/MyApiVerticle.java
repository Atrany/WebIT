package webit;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.Router;


public class MyApiVerticle extends AbstractVerticle {
  private static final Logger LOGGER = LoggerFactory.getLogger(MyApiVerticle.class);

  @Override
  public void start() throws Exception {
    LOGGER.info("Dans le start...");
    final Router router = Router.router(vertx);
    final BookResource bookResource = new BookResource();
    final Router bookSubRouter = bookResource.getSubRouter(vertx);
    router.mountSubRouter("/api/v1/books", bookSubRouter);
    vertx.createHttpServer()
        .requestHandler(router)
        .listen(8080);
  }

  @Override
  public void stop() throws Exception {
    LOGGER.info("Dans le stop...");
  }
}